
//googleAPI object holds url and key for the Google geocode API
var googleAPI = {
    url: "https://maps.googleapis.com/maps/api/geocode/json?",
    key: "&key=AIzaSyDPNJxvmbwoFvXhVb9jH3TSGubXK5DKA1U"
};

// HTML Pull
var inputBox = $("#address-input");
var addressDisp = $("#address-display");
var latDisp = $("#lat-display");
var lngDisp = $("#lng-display");
var geoDisp = $("#global-geo");


//Event handler for the "View Results" button
$("#go-button").on("click", function (event) {
    event.preventDefault();
    // Assign user's inputted address to inputAddress
    let inputAddress = inputBox.val();

    // Perform an ajax call to the Google Geocode API
    try {
        $.ajax({
            url: googleAPI.url + "address=" + inputAddress + googleAPI.key,
            method: "GET"
        }).then(function (response) {
            console.log(response.results);

            // Populate respective results to the page
            addressDisp.text(response.results[0].formatted_address);
            latDisp.text(response.results[0].geometry.location.lat);
            lngDisp.text(response.results[0].geometry.location.lng);
            geoDisp.text(response.results[0].place_id);

            // Pass the resulting latitude and longitude to localStorage
            localStorage.setItem("usrAddress", response.results[0].formatted_address);
            localStorage.setItem("usrLat", response.results[0].geometry.location.lat);
            localStorage.setItem("usrLng", response.results[0].geometry.location.lng);

            //Enable the View Map button by replacing the empty href with a link to the viewMap page
            // $("#map-redirect").attr("href","viewMap.html");
        });
    } catch (err) {
        console.log(err);
        alert("Something went wrong.");
    }
});